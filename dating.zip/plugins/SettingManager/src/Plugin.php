<?php

namespace SettingManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for SettingManager
 */
class Plugin extends BasePlugin
{
}
