<?php

namespace BannerManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for BannerManager
 */
class Plugin extends BasePlugin
{
}
