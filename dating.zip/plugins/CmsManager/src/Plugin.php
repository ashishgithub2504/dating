<?php

namespace CmsManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for CmsManager
 */
class Plugin extends BasePlugin
{
}
