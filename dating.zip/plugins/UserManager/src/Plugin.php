<?php

namespace UserManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for UserManager
 */
class Plugin extends BasePlugin
{
}
