<?php

namespace UserManager\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{

}
