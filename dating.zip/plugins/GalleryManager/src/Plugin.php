<?php

namespace GalleryManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for GalleryManager
 */
class Plugin extends BasePlugin
{
}
