function deleteimage(){
	alert('sdsad');
}