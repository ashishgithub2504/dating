<?php

namespace CatalogManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for CatalogManager
 */
class Plugin extends BasePlugin
{
}
