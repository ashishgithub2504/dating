<?php

namespace BackEnd;

use Cake\Core\BasePlugin;

/**
 * Plugin for BackEnd
 */
class Plugin extends BasePlugin
{
}
