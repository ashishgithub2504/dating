<?php

namespace AdminUserManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for AdminUserManager
 */
class Plugin extends BasePlugin
{
}
