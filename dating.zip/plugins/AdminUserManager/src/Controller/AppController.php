<?php

namespace AdminUserManager\Controller;

use App\Controller\AppController as BaseController;

class AppController extends BaseController
{

}
