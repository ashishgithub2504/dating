<?php

namespace ContactManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for ContactManager
 */
class Plugin extends BasePlugin
{
}
