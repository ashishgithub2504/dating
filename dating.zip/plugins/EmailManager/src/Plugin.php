<?php

namespace EmailManager;

use Cake\Core\BasePlugin;

/**
 * Plugin for EmailManager
 */
class Plugin extends BasePlugin
{
}
