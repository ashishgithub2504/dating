<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/form.twig */
class __TwigTemplate_5d825f9097982e8c6788b4583db3e4f06965daf3b114ce9c4a476d421a20bef0 extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa = $this->env->getExtension("WyriHaximus\\TwigView\\Lib\\Twig\\Extension\\Profiler");
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->enter($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "/home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/form.twig"));

        // line 17
        $context["fields"] = $this->getAttribute(($context["Bake"] ?? null), "filterFields", [0 => ($context["fields"] ?? null), 1 => ($context["schema"] ?? null), 2 => ($context["modelObject"] ?? null)], "method");
        // line 18
        echo "<section class=\"content-header\">
    <h1>
        <?php echo __('Manage ";
        // line 20
        echo twig_escape_filter($this->env, ($context["singularHumanName"] ?? null), "html", null, true);
        echo "'); ?> <small>
            <?php echo empty(\$";
        // line 21
        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
        echo "->";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["primaryKey"] ?? null), 0, [], "array"), "html", null, true);
        echo ") ? __('Add New ";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["singularHumanName"] ?? null)), "html", null, true);
        echo "') : __('Edit ";
        echo twig_escape_filter($this->env, twig_lower_filter($this->env, ($context["singularHumanName"] ?? null)), "html", null, true);
        echo "'); ?>
        </small>
    </h1>
    <?= \$this->element('breadcrumb'); ?>
</section>
";
        // line 53
        echo "<section class=\"content\" data-table=\"";
        echo twig_escape_filter($this->env, ($context["pluralVar"] ?? null), "html", null, true);
        echo "\">
    <div class=\"box box-info ";
        // line 54
        echo twig_escape_filter($this->env, ($context["pluralVar"] ?? null), "html", null, true);
        echo "\">
        <div class=\"box-header with-border\">
            <h3 class=\"box-title\"><?= __(empty(\$";
        // line 56
        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
        echo "->";
        echo twig_escape_filter($this->env, $this->getAttribute(($context["primaryKey"] ?? null), 0, [], "array"), "html", null, true);
        echo ") ? 'Add ";
        echo twig_escape_filter($this->env, ($context["singularHumanName"] ?? null), "html", null, true);
        echo "' : 'Edit ";
        echo twig_escape_filter($this->env, ($context["singularHumanName"] ?? null), "html", null, true);
        echo "') ?></h3>
            <?php echo \$this->Html->link(\"<i class='fa fa-fw fa-chevron-circle-left'></i> \".__('Back'), ['action' => 'index'], ['class' => 'btn btn-default pull-right', 'title' => __('Cancel'),'escape'=>false]); ?>
        </div><!-- /.box-header -->
    <?php
    \$this->loadHelper('Form', [
        'templates' => 'default_form',
    ]);
    ?>
    <?= \$this->Form->create(\$";
        // line 64
        echo twig_escape_filter($this->env, ($context["singularVar"] ?? null), "html", null, true);
        echo ", ['role' => 'form', 'enctype' => 'multipart/form-data']) ?>
   <div class=\"box-body\">
       <div class=\"row\">
                <div class=\"col-md-12\">
<?php
";
        // line 69
        $context['_parent'] = $context;
        $context['_seq'] = twig_ensure_traversable(($context["fields"] ?? null));
        foreach ($context['_seq'] as $context["_key"] => $context["field"]) {
            if (!twig_in_filter($context["field"], ($context["primaryKey"] ?? null))) {
                // line 70
                if ($this->getAttribute(($context["keyFields"] ?? null), $context["field"], [], "array")) {
                    // line 71
                    $context["fieldData"] = $this->getAttribute(($context["Bake"] ?? null), "columnData", [0 => $context["field"], 1 => ($context["schema"] ?? null)], "method");
                    // line 72
                    if ($this->getAttribute(($context["fieldData"] ?? null), "null", [])) {
                        // line 73
                        echo "            echo \$this->Form->control('";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "', ['options' => \$";
                        echo twig_escape_filter($this->env, $this->getAttribute(($context["keyFields"] ?? null), $context["field"], [], "array"), "html", null, true);
                        echo ", 'empty' => true, 'class' => 'form-control']);";
                        // line 74
                        echo "
";
                    } else {
                        // line 76
                        echo "            echo \$this->Form->control('";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "', ['options' => \$";
                        echo twig_escape_filter($this->env, $this->getAttribute(($context["keyFields"] ?? null), $context["field"], [], "array"), "html", null, true);
                        echo ",'class' => 'form-control']);";
                        // line 77
                        echo "
";
                    }
                } elseif (!twig_in_filter(                // line 79
$context["field"], [0 => "created", 1 => "modified", 2 => "updated", 3 => "deleted_date"])) {
                    // line 80
                    $context["fieldData"] = $this->getAttribute(($context["Bake"] ?? null), "columnData", [0 => $context["field"], 1 => ($context["schema"] ?? null)], "method");
                    // line 81
                    if ((twig_in_filter($this->getAttribute(($context["fieldData"] ?? null), "type", []), [0 => "date", 1 => "datetime", 2 => "time"]) && $this->getAttribute(($context["fieldData"] ?? null), "null", []))) {
                        // line 82
                        echo "            echo \$this->Form->control('";
                        echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                        echo "', ['empty' => true,'type'=>'text', 'class' => 'form-control datepicker', 'placeholder' => __('";
                        echo twig_escape_filter($this->env, Cake\Utility\Inflector::humanize(Cake\Utility\Inflector::underscore($context["field"])), "html", null, true);
                        echo "')]);";
                        // line 83
                        echo "
";
                    } else {
                        // line 85
                        if (($context["field"] == "status")) {
                            // line 86
                            echo "            echo \$this->Form->control('";
                            echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                            echo "',['options'=>[1 => \"Active\", 0 => \"Inactive\"],'class' => 'form-control']);";
                        } else {
                            // line 88
                            if ((twig_in_filter($this->getAttribute(($context["fieldData"] ?? null), "type", []), [0 => "tinyint"]) && $this->getAttribute(($context["fieldData"] ?? null), "null", []))) {
                                // line 89
                                echo "                echo \$this->Form->control('";
                                echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                                echo "');";
                            } else {
                                // line 91
                                echo "                echo \$this->Form->control('";
                                echo twig_escape_filter($this->env, $context["field"], "html", null, true);
                                echo "',['class' => 'form-control', 'placeholder' => __('";
                                echo twig_escape_filter($this->env, Cake\Utility\Inflector::humanize(Cake\Utility\Inflector::underscore($context["field"])), "html", null, true);
                                echo "')]);";
                            }
                        }
                        // line 94
                        echo "
";
                    }
                }
            }
        }
        $_parent = $context['_parent'];
        unset($context['_seq'], $context['_iterated'], $context['_key'], $context['field'], $context['_parent'], $context['loop']);
        $context = array_intersect_key($context, $_parent) + $_parent;
        // line 99
        if ($this->getAttribute(($context["associations"] ?? null), "BelongsToMany", [])) {
            // line 100
            $context['_parent'] = $context;
            $context['_seq'] = twig_ensure_traversable($this->getAttribute(($context["associations"] ?? null), "BelongsToMany", []));
            foreach ($context['_seq'] as $context["assocName"] => $context["assocData"]) {
                // line 101
                echo "            echo \$this->Form->control('";
                echo twig_escape_filter($this->env, $this->getAttribute($context["assocData"], "property", []), "html", null, true);
                echo "._ids', ['options' => \$";
                echo twig_escape_filter($this->env, $this->getAttribute($context["assocData"], "variable", []), "html", null, true);
                echo "]);";
                // line 102
                echo "
";
            }
            $_parent = $context['_parent'];
            unset($context['_seq'], $context['_iterated'], $context['assocName'], $context['assocData'], $context['_parent'], $context['loop']);
            $context = array_intersect_key($context, $_parent) + $_parent;
        }
        // line 105
        echo "        ?>
</div>
</div>
    </div>
        <div class=\"box-footer\">
            <?php echo \$this->Form->button(\"<i class='fa fa-fw fa-save'></i> \".__('Submit'), ['class' => 'btn btn-primary btn-flat', 'title' => __('Submit')]); ?>  
            <?php echo \$this->Html->link(\"<i class='fa fa-fw fa-chevron-circle-left'></i> \".__('Back'), ['action' => 'index'], ['class' => 'btn btn-warning btn-flat', 'title' => __('Cancel'),'escape'=>false]); ?>
        </div>
    <?= \$this->Form->end() ?>
</div>
        </section>
";
        
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->leave($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof);

    }

    public function getTemplateName()
    {
        return "/home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/form.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  191 => 105,  183 => 102,  177 => 101,  173 => 100,  171 => 99,  161 => 94,  153 => 91,  148 => 89,  146 => 88,  141 => 86,  139 => 85,  135 => 83,  129 => 82,  127 => 81,  125 => 80,  123 => 79,  119 => 77,  113 => 76,  109 => 74,  103 => 73,  101 => 72,  99 => 71,  97 => 70,  92 => 69,  84 => 64,  67 => 56,  62 => 54,  57 => 53,  43 => 21,  39 => 20,  35 => 18,  33 => 17,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("{#
/**
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 * @author        Hanuman Yadav
 * @author        Hanuman yadav <jainashish2504@gmail.com>
 * @copyright     2018-19 The Ashish Cakephp Team (https://www.ashsih.com)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @since         2.0.0
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
#}
{% set fields = Bake.filterFields(fields, schema, modelObject) %}
<section class=\"content-header\">
    <h1>
        <?php echo __('Manage {{ singularHumanName }}'); ?> <small>
            <?php echo empty(\${{ singularVar }}->{{ primaryKey[0] }}) ? __('Add New {{ singularHumanName|lower }}') : __('Edit {{ singularHumanName|lower }}'); ?>
        </small>
    </h1>
    <?= \$this->element('breadcrumb'); ?>
</section>
{#<nav class=\"large-3 medium-4 columns\" id=\"actions-sidebar\">
    <ul class=\"side-nav\">
        <li class=\"heading\"><?= __('Actions') ?></li>
{% if strpos(action, 'add') is same as(false) %}
        <li><?= \$this->Form->postLink(
                __('Delete'),
                ['action' => 'delete', \${{ singularVar }}->{{ primaryKey[0] }}],
                ['confirm' => __('Are you sure you want to delete # {0}?', \${{ singularVar }}->{{ primaryKey[0] }})]
            )
        ?></li>
{% endif %}
        <li><?= \$this->Html->link(__('List {{ pluralHumanName }}'), ['action' => 'index']) ?></li>
        {{- \"\\n\" }}
{%- set done = [] %}
{% for type, data in associations %}
    {%- for alias, details in data %}
        {%- if details.controller is not same as(_view.name) and details.controller not in done %}
        <li><?= \$this->Html->link(__('List {{ alias|underscore|humanize }}'), ['controller' => '{{ details.controller }}', 'action' => 'index']) ?></li>
        <li><?= \$this->Html->link(__('New {{ alias|singularize|underscore|humanize }}'), ['controller' => '{{ details.controller }}', 'action' => 'add']) ?></li>
        {{- \"\\n\" }}
        {%- set done = done|merge([details.controller]) %}
        {%- endif %}
    {%- endfor %}
{% endfor %}
    </ul>
</nav>
#}
<section class=\"content\" data-table=\"{{ pluralVar }}\">
    <div class=\"box box-info {{ pluralVar }}\">
        <div class=\"box-header with-border\">
            <h3 class=\"box-title\"><?= __(empty(\${{ singularVar }}->{{ primaryKey[0] }}) ? 'Add {{ singularHumanName }}' : 'Edit {{ singularHumanName }}') ?></h3>
            <?php echo \$this->Html->link(\"<i class='fa fa-fw fa-chevron-circle-left'></i> \".__('Back'), ['action' => 'index'], ['class' => 'btn btn-default pull-right', 'title' => __('Cancel'),'escape'=>false]); ?>
        </div><!-- /.box-header -->
    <?php
    \$this->loadHelper('Form', [
        'templates' => 'default_form',
    ]);
    ?>
    <?= \$this->Form->create(\${{ singularVar }}, ['role' => 'form', 'enctype' => 'multipart/form-data']) ?>
   <div class=\"box-body\">
       <div class=\"row\">
                <div class=\"col-md-12\">
<?php
{% for field in fields if field not in primaryKey %}
    {%- if keyFields[field] %}
        {%- set fieldData = Bake.columnData(field, schema) %}
        {%- if fieldData.null %}
            echo \$this->Form->control('{{ field }}', ['options' => \${{ keyFields[field] }}, 'empty' => true, 'class' => 'form-control']);
            {{- \"\\n\" }}
        {%- else %}
            echo \$this->Form->control('{{ field }}', ['options' => \${{ keyFields[field] }},'class' => 'form-control']);
            {{- \"\\n\" }}
        {%- endif %}
    {%- elseif field not in ['created', 'modified', 'updated','deleted_date'] %}
        {%- set fieldData = Bake.columnData(field, schema) %}
        {%- if fieldData.type in ['date', 'datetime', 'time'] and fieldData.null %}
            echo \$this->Form->control('{{ field }}', ['empty' => true,'type'=>'text', 'class' => 'form-control datepicker', 'placeholder' => __('{{ field|underscore|humanize }}')]);
            {{- \"\\n\" }}
        {%- else %}
            {%-  if field == \"status\" %}
            echo \$this->Form->control('{{ field }}',['options'=>[1 => \"Active\", 0 => \"Inactive\"],'class' => 'form-control']);
            {%- else %}
            {%- if fieldData.type in ['tinyint'] and fieldData.null %}
                echo \$this->Form->control('{{ field }}');
            {%- else %}
                echo \$this->Form->control('{{ field }}',['class' => 'form-control', 'placeholder' => __('{{ field|underscore|humanize }}')]);
            {%- endif %}
            {%- endif %}
    {{- \"\\n\" }}
        {%- endif %}
    {%- endif %}
{%- endfor %}

{%- if associations.BelongsToMany %}
    {%- for assocName, assocData in associations.BelongsToMany %}
            echo \$this->Form->control('{{ assocData.property }}._ids', ['options' => \${{ assocData.variable }}]);
    {{- \"\\n\" }}
    {%- endfor %}
{% endif %}
        ?>
</div>
</div>
    </div>
        <div class=\"box-footer\">
            <?php echo \$this->Form->button(\"<i class='fa fa-fw fa-save'></i> \".__('Submit'), ['class' => 'btn btn-primary btn-flat', 'title' => __('Submit')]); ?>  
            <?php echo \$this->Html->link(\"<i class='fa fa-fw fa-chevron-circle-left'></i> \".__('Back'), ['action' => 'index'], ['class' => 'btn btn-warning btn-flat', 'title' => __('Cancel'),'escape'=>false]); ?>
        </div>
    <?= \$this->Form->end() ?>
</div>
        </section>
", "/home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/form.twig", "/home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/form.twig");
    }
}
