<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* /home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/Controller/changeFlag.twig */
class __TwigTemplate_27bfb1501018462b95bd80519d971ad94d87c7edf469a5bb76eeecffd08c5fef extends \Twig\Template
{
    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa = $this->env->getExtension("WyriHaximus\\TwigView\\Lib\\Twig\\Extension\\Profiler");
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->enter($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "/home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/Controller/changeFlag.twig"));

        // line 1
        echo "  /**
     * ChangeFlag method
     *
     * @param string|null &id flag id.
     * @param string|null &id field those update table field.
     * @param string|null &status Admin status.
     * @return \\Cake\\Http\\Response|null Redirects to index.
     * @throws \\Cake\\Datasource\\Exception\\RecordNotFoundException When record not found.
     */
    public function changeFlag()
    {
        if (\$this->request->is('ajax') && \$this->request->getData('id')) {
            \$status = \$this->";
        // line 13
        echo twig_escape_filter($this->env, ($context["currentModelName"] ?? null), "html", null, true);
        echo "->newEntity();
            \$field = \$this->request->getData('field');
            \$status->id = \$this->request->getData('id');
            \$status->\$field = \$this->request->getData('status');
            if (\$this->";
        // line 17
        echo twig_escape_filter($this->env, ($context["currentModelName"] ?? null), "html", null, true);
        echo "->save(\$status)) {
                \$msg = \$this->request->getData(\$field) == 1 ? __(\"Your {\$field} has activated\") : __(\"Your {\$field} has deactivated\");
                \$response = [\"success\" => true, \"err_msg\" => \$msg];
            } else {
                \$response = [\"success\" => false, \"err_msg\" => __(\"Your Process faild. please try again!!\")];
            }
            \$this->set([
                'success' => \$response['success'],
                'responce' => 200,
                'message' => \$response['err_msg'],
                '_jsonOptions' => JSON_FORCE_OBJECT,
                '_serialize' => ['success', 'responce', 'message']
            ]);
        }
        
    }
";
        
        $__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa->leave($__internal_770edd655cdeb606afc443e4edb1f19b4248a91788cb82e88bf8b9495a7c5cfa_prof);

    }

    public function getTemplateName()
    {
        return "/home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/Controller/changeFlag.twig";
    }

    public function isTraitable()
    {
        return false;
    }

    public function getDebugInfo()
    {
        return array (  54 => 17,  47 => 13,  33 => 1,);
    }

    /** @deprecated since 1.27 (to be removed in 2.0). Use getSourceContext() instead */
    public function getSource()
    {
        @trigger_error('The '.__METHOD__.' method is deprecated since version 1.27 and will be removed in 2.0. Use getSourceContext() instead.', E_USER_DEPRECATED);

        return $this->getSourceContext()->getCode();
    }

    public function getSourceContext()
    {
        return new Source("  /**
     * ChangeFlag method
     *
     * @param string|null &id flag id.
     * @param string|null &id field those update table field.
     * @param string|null &status Admin status.
     * @return \\Cake\\Http\\Response|null Redirects to index.
     * @throws \\Cake\\Datasource\\Exception\\RecordNotFoundException When record not found.
     */
    public function changeFlag()
    {
        if (\$this->request->is('ajax') && \$this->request->getData('id')) {
            \$status = \$this->{{ currentModelName }}->newEntity();
            \$field = \$this->request->getData('field');
            \$status->id = \$this->request->getData('id');
            \$status->\$field = \$this->request->getData('status');
            if (\$this->{{ currentModelName }}->save(\$status)) {
                \$msg = \$this->request->getData(\$field) == 1 ? __(\"Your {\$field} has activated\") : __(\"Your {\$field} has deactivated\");
                \$response = [\"success\" => true, \"err_msg\" => \$msg];
            } else {
                \$response = [\"success\" => false, \"err_msg\" => __(\"Your Process faild. please try again!!\")];
            }
            \$this->set([
                'success' => \$response['success'],
                'responce' => 200,
                'message' => \$response['err_msg'],
                '_jsonOptions' => JSON_FORCE_OBJECT,
                '_serialize' => ['success', 'responce', 'message']
            ]);
        }
        
    }
", "/home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/Controller/changeFlag.twig", "/home/ashishjain/projects/dating/plugins/BackEnd/src/Template/Bake/Element/Controller/changeFlag.twig");
    }
}
